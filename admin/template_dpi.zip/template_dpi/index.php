<?php

print "<META http-equiv='refresh' content=0;URL=dashboard.html>";
exit;
?>